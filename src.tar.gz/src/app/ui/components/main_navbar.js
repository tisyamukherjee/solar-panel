export default function Navbar() {
    


    return (
    <div class="w-full p-8 flex justify-between items-center text-white bg-blue-950">
        <div class="flex flex-row gap-4">
        hi
        </div>

        <div class="flex flex-col gap-2 divide-x sm:gap-4 sm:flex-row">
        <span class="px-2">01</span>
        <span class="px-2">02</span>
        <span class="px-2">03</span>
        </div>
    </div>
    )
}