import Footer from "../ui/components/footer";

export default function Page() {
    return (
        <>
            <div>
                <p>Hello World</p>
            </div>
        </>
    )
}